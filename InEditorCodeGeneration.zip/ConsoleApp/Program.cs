﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
void Test()
{
    Console.WriteLine("Test");
}

record User
{
    public string FirstName { get; init; }
    public string LastName { get; init; }
    public int Age { get; init; }
    public int NumberOfCats { get; init; }

    public void Deconstruct(out string firstName, out string lastName, out int age, out int numberOfCats)
    {
        firstName = FirstName;
        lastName = LastName;
        age = Age;
        numberOfCats = NumberOfCats;
        
        // Additional code
        Console.WriteLine($"User: {FirstName} {LastName}, Age: {Age}, Number of Cats: {NumberOfCats}");
        
        var s = "";

        void Test()
        {
            Console.WriteLine("Test");
        }
    }
}